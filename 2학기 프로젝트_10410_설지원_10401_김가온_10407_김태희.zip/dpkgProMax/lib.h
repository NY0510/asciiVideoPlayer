int pkg_install(char* package);
int pkg_search(char* package);
int pkg_remove(char* package);
int pkg_upgrade(char* package);

